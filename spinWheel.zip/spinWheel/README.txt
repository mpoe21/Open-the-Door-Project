In this project, I changed the theme to present fun facts about animals for kids. I changed the wheel options, the messages, the wheel colors, and added a title. I aimed this for kids to provide them a fun opportunity to learn some facts about their favorite animals. 

GitHub link: https://github.com/mpoe21/mpoe21.github.io

